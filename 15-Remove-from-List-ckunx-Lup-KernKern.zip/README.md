# Remove Numbers

In this hands-on, you are provided with a `Numbers` component. Inside the component's state there is array named `numbers` with some numbers stored inside.

Your task is to complete the `removeAtRandom` function such that whenever the `Remove Random` button, one number is removed at random from the `numbers` state array.