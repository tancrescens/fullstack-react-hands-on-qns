1. Add to the component's **state** a state variable with the name `displayMessage`

2. Add an event handler for each of the three buttons. Display the text within the `<div className='display'>` element.

   * When the "Coffee" button is pressed,
   display "Dispensing coffee"

   * When the "Tea" button is pressed,
   display "Dispensing tea"

   * When the "Orange Juice" button is pressed, display "Dispening orange jucie"



