import React from 'react';
import Trouble from './Trouble'
import './App.css';

function App() {
  return (
    <div className="App">
        <Trouble/>
    </div>
  );
}

export default App;
