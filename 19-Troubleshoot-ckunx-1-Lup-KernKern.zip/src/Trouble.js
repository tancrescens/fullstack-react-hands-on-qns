import React from 'react'

export default class Trouble extends React.Component {
  faults = [];
  state = {
    'faults': [
      {
        'id': 101,
        'email': 'jan@abc.com',
        'name': 'Jan Cook',
        'trouble_type': 'equipment-fault',
        'description':'Lift is not working',
        'tags':['urgent', 'electricial']
      }
    ],
    newFaultEmail:"",
    newFaultName:"",
    newTroubleType:"",
    newDescription:"",
    newTags:[]
  }

  displayFaults() {
    let faultList = [];
    for (let f of this.faults) {
      faultList.push(<div>
          <h5>{f.name}</h5>
          <h6>Reported by: <span>f.name (f.email)</span></h6>
          <h6>Trouble: <span>f.trouble_type</span></h6>
          <h6>Tags:<span>{f.tags.join(',')}</span></h6>
          <p>
            {f.description}
          </p>
      </div>)
    }
  }

  updateEmail = (e) => {
      this.state.newFaultEmail = e.target.value;
  }
  

  updateFormField = (e) => {
    this.setState({
      'e.target.name': e.target.value
    })
  }

  updateCheckbox = (e) =>{
    this.setState({
      [e.target.name] : e.target.value
    })
  }

  addFault = () => {
    let randomID = Math.random() * 10000 + 99999;

    let newFault = {
      id: randomID,
      email: this.state.newFaultEmail,
      name: this.state.newFaultName,
      trouble_type: this.state.newTroubleType,
      description: this.state.newDescription,
      tags:this.state.newTags
    }

    // make a clone
    let clone = this.state.faults;

    // push into the clone
    clone.push(newFault);

    // overwrite the state
    this.setState({
      'clone': clone
    })
  }

  render() {
    return <React.Fragment>
      <div class="container">
        <div class="col">
            {this.displayFaults()}
        </div>

        <div class="col">

          <h3>Add Fault</h3>
          <div>
            <label>Email:</label>
            <input type="text" name="email" onChange={this.updateEmail} value={this.state.newFaultEmail}/>
          </div>
          <div>
            <label>Name</label>
            <input type="text" name="email" value={this.state.newFaultEmail} onChange={this.updateFormField}/>
          </div>
            <div>
            <label>Description</label>
            <input type="text" name="description" value={this.state.newTroubleType} onChange={this.updateFormField}/>
          </div>
          <div>
            <label>Trouble Type</label>

            <input type="radio" name="trouble_type" value="equipment-fault" onChange={this.updateCheckbox}/><label>Equipment Fault</label>

             <input type="radio" name="trouble_type" value="building-defect" onChange={this.updateCheckbox}/><label>Building Defect</label>

            <input type="radio" name="trouble_type" value="other-complaints" onChange={this.updateCheckbox}/><label>Others</label>
          
          </div>
          <div>
            <label>Tags</label>
            <input type="checkbox" name="tags" value="urgent" onChange={this.updateCheckbox}/><label>Urgent</label>
            <input type="checkbox" name="tags" value="dangerous" onChange={this.updateCheckbox}/><label>Dangerous</label>
            <input type="checkbox" name="tags" value="public-areas" onChange={this.updateCheckbox}/><label>Public Areas</label>
            <input type="checkbox" name="tags" value="electrical" onChange={this.updateCheckbox}/><label>Electrical</label>
          </div>
          <button onClick={this.addFault}>Add Fault</button>
        </div>
      </div>
    </React.Fragment>
  }
}