# MCQ Questions

There is a component `Question` which represents one question in a MCQ quiz. 

Your tasks are to implement the following:

1. When the user selects a radio button, update the `answer` state variable to the value of the selected radio button.

2. When the state variable `answer` is switch to A, B, C or D, set the radio button corresponding as checked.