# Troubleshooting

There is a whole bunch of problem with the React program. Troubleshoot and solve the following problems:

* You cannot type into the text fields
* Text field are not updating the state properly
* Checkboxes are not updating the state properly
* Existing faults are not displaying 
* Existing faults are not displayed properly
* Changing the state for the `trouble_type` does not update `newFaultTroubleType` variable in the state
