import React from 'react';
import Tastes from './Tastes'
import './App.css';

function App() {
  return (
    <div className="App">
      <Tastes/>
    </div>
  );
}

export default App;
