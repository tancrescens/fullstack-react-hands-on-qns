import React from 'react'

export default class Buffet extends React.Component {
  state = {
    items: []
  }
  render() {
    return (
      <React.Fragment>
          <div>
            <input type="checkbox" name="orders" value="beef"/><label>Shabu Shabu Beef</label>
          </div>
          <div>
            <input type="checkbox" name="orders" value="chicken"/><label>Chicken Fillet</label>
          </div>
          <div>
            <input type="checkbox" name="orders" value="fish"/><label>Fish Fillet</label>
          </div>
          <div>
            <input type="checkbox" name="orders" value="mushrooms"/><label>Assorted mushhrooms</label>
          </div>
          <div>
            <input type="checkbox" name="orders" value="spinach"/><label>Spinach</label>
          </div>
          <h1>Total:{this.calculateTotal()}</h1>
      </React.Fragment>
    )
  }
  calculateTotal = () => {
    return 0;
  }
}