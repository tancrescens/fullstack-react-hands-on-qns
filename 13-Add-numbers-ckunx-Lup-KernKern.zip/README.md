# Add Numbers

In this hands-on, you will be given a list of numbers, and a button that says `Add Random`. You will also be given a textbox and a button with the label `Add` next to it.

You are to modify the `Numbers` components and fufill the following tasks:

1. Complete the given `addRandom` function such that Whenever the `Add Random` button is added, add a random number into the `numbers` array in the state. 

2. Add code such that the user can type in any number into the textbox, and when they press the `Add Number` button, the number in the textbox will be appended to the end of the list.