import React from 'react';
import './App.css';
import Movies from './Movies'

function App() {
  return (
    <div>
      <Movies/>
    </div>

  );
}

export default App;
