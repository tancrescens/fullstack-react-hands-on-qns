# String to Tags

There is a three checkboxes - spicy, sour and sweet. They have been given a value (hint: those values are important in solving the problems.) The checkboxes are all unchecked initially. 

There are also three buttons, each of them being __Toggle Spicy__, __Toggle Sour__ and __Toggle Sweet__.

1. When the user clicks on __Toggle Spicy__, the checkbox for `Spicy` should be checked if it wasn't, and should be unchecked if it was.

2. When the user clicks on __Toggle Sour__, the checkbox for `Sour` should be checked if it wasn't, and should be unchecked if it was.

3. When the user clicks on __Toggle Sweet__, the checkbox for `Sweet` should be checked if it wasn't, and should be unchecked if it was.