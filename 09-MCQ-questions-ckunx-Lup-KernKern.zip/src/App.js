import React from 'react';
import './App.css';
import Question from './Question'

function App() {
  return (
    <article className="App">
      <Question/>
    </article>
  );
}

export default App;
