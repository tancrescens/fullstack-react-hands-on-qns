import React from 'react';

export default class App extends React.Component {
  state = {
    
  }
  render() {
    return (
      <React.Fragment>
        <h1>Drink Vending Machine</h1>
        <div className="display">
        </div>
        <button>Coffee</button>
        <button>Tea</button>
        <button>Orange Juice</button>
      </React.Fragment>
    );
  }
}


