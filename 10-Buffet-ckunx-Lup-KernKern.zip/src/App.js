import React from 'react';
import './App.css';
import Buffet from './Buffet'

function App() {
  return (
    <div className="App">
      <Buffet/>
    </div>
  );
}

export default App;
