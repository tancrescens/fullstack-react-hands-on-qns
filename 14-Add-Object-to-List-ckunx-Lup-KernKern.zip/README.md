# Add Objects to List

In the `Movies` component, a number of movies are displayed. Your task is to complete the `addMovie` function so that the user can add a new movie to the __back__ of the `movies` array (which is in the state.)

The form and its varioius state variables have already been setup. 
