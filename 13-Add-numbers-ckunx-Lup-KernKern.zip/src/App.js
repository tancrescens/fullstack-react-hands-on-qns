import React from 'react';
import './App.css';
import Numbers from "./Numbers"

function App() {
  return (
    <div className="App">
      <Numbers/>
    </div>
  );
}

export default App;
